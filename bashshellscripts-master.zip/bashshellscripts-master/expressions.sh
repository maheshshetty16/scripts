#!/bin/bash
# expression evaluation
expr 2 + 2
expr 2 + 2 \* 4
expr \( 2 + 2 \) \* 4