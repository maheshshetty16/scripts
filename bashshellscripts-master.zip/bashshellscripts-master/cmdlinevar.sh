==============================
SCRIPT NAME: cmdlinevar.sh
==============================
#!/bin/bash
# demo of command line values passed in with our shell script
USERNAME=$1
PASSWORD=$2
echo "The following Username is $USERNAME and Password is $PASSWORD"